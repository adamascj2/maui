﻿using System;

using AppKit;
using Foundation;

namespace HelloMacOS
{
    public partial class ViewController : NSViewController
    {
        public ViewController(IntPtr handle) : base(handle)
        {
        }
    }
}
