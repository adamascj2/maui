using AppKit;
using Foundation;

namespace HelloMacOS
{
    [Register("AppDelegate")]
    public class AppDelegate : NSApplicationDelegate
    {
        public AppDelegate()
        {
        }
    }
}
