﻿using Foundation;
using Microsoft.Maui;

namespace HelloMaui
{
	[Register("AppDelegate")]
	public class AppDelegate : MauiUIApplicationDelegate<Startup>
	{
	}
}