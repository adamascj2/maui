﻿using Android.App;
using Microsoft.Maui;

namespace HelloMaui
{
	[Activity(Theme = "@style/AppTheme.NoActionBar", MainLauncher = true)]
	public class MainActivity : MauiAppCompatActivity
	{
	}
}